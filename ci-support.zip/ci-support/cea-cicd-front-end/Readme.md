## README: CEA-CICD

### Iniciando a Aplicação
Com o NPM pre-instalado, execute o comando abaixo:
```sh
npm start
```