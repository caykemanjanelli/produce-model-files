echo 'Iniciando instalação do Drive teradata - tdgssconfig - versão 16.20.00.10'
echo ' '
chmod 777 tdgssconfig-16.20.00.10..sh
chmod a+x tdgssconfig-16.20.00.10..sh
./tdgssconfig-16.20.00.10..sh
echo ' '
echo 'Fim da instalação'
