# !/bash/sh
# Importando/Instalando dependência:

mvn install:install-file -Dfile=${PWD}'\tdgssconfig-16.20.00.10.jar' -DgroupId=com.teradata.jdbc -DartifactId=tdgssconfig -Dversion=16.20.00.10 -Dpackaging=jar
