echo 'Iniciando instalação do Drive teradata - tdgssconfig - versão 16.00.00.01'
echo ' '
chmod 777 tdgssconfig-16.00.00.01.sh
chmod a+x tdgssconfig-16.00.00.01.sh
./tdgssconfig-16.00.00.01.sh
echo ' '
echo 'Fim da instalação'
