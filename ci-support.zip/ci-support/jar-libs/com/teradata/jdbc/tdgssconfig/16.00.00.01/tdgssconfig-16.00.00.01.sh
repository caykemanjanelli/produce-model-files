# !/bash/sh
# Importando/Instalando dependência:

mvn install:install-file -Dfile=${PWD}'\tdgssconfig-16.00.00.01.jar' -DgroupId=com.teradata.jdbc -DartifactId=tdgssconfig -Dversion=16.00.00.01 -Dpackaging=jar
