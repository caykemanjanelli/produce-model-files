echo 'Iniciando instalação do Drive teradata - terajdbc4 - versão 15.10.00.37'
echo ' '
chmod 777 terajdbc4-15.10.00.37.sh
chmod a+x terajdbc4-15.10.00.37.sh
./terajdbc4-15.10.00.37.sh
echo ' '
echo 'Fim da instalação'
