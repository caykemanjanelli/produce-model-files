# !/bash/sh
# Importando/Instalando dependência:

mvn install:install-file -Dfile=${PWD}'\terajdbc4-15.10.00.37.jar' -DgroupId=com.teradata.jdbc -DartifactId=terajdbc4 -Dversion=15.10.00.37 -Dpackaging=jar
