### Passo a passo para instalar Lib

## Clonar projeto
Abra o gitBash ou o terminal (Linux ou Mac) e execute o comando abaixo:

```sh
$ git clone git@git.cea.com.br:ci-support/jar-libs.git
$ cd jar-libs/com/teradata/jdbc/terajdbc4/16.20.00.10/
$ ./run.sh
```