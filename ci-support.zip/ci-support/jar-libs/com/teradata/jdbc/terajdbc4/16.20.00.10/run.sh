echo 'Iniciando instalação do Drive teradata - terajdbc4 - versão 16.20.00.10'
echo ' '
chmod 777 terajdbc4-16.20.00.10.sh
chmod a+x terajdbc4-16.20.00.10.sh
./terajdbc4-16.20.00.10.sh
echo ' '
echo 'Fim da instalação'
