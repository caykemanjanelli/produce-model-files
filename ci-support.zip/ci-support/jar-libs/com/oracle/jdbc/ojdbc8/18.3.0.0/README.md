### Passo a passo para instalar Lib

## Clonar projeto
Abra o gitBash ou o terminal (Linux ou Mac) e execute o comando abaixo:

```sh
$ git clone git@git.cea.com.br:ci-support/jar-libs.git
$ cd jar-libs/com/oracle/jdbc/ojdbc8/18.3.0.0/
$ ./run.sh
```