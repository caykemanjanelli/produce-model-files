# !/bash/sh
# Importando/Instalando dependência:

mvn install:install-file -Dfile=${PWD}'\ojdbc8-18.3.0.0.jar' -DgroupId=com.oracle.jdbc -DartifactId=ojdbc8 -Dversion=18.3.0.0 -Dpackaging=jar
