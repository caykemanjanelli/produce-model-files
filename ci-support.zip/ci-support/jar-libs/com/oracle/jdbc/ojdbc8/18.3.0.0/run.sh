echo 'Iniciando instalação do Drive Oracle - Jdbc8 - versão 18.3.0.0'
echo ' '
chmod 777 ojdbc8-18.3.0.0.sh
chmod a+x ojdbc8-18.3.0.0.sh
./ojdbc8-18.3.0.0.sh
echo ' '
echo 'Fim da instalação'
