# !/bash/sh
# Importando/Instalando dependência:

mvn install:install-file -Dfile=${PWD}'\ojdbc6-11.2.0.3.jar' -DgroupId=com.oracle.jdbc -DartifactId=ojdbc6 -Dversion=11.2.0.3 -Dpackaging=jar
