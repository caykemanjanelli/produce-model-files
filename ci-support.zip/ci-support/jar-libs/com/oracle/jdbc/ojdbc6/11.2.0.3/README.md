### Passo a passo para instalar Lib

## Clonar projeto
Abra o gitBash ou o terminal (Linux ou Mac) e execute o comando abaixo:

```sh
$ git clone git@git.cea.com.br:ci-support/jar-libs.git
$ cd jar-libs/com/oracle/jdbc/ojdbc6/11.2.0.3/
$ ./run.sh
```