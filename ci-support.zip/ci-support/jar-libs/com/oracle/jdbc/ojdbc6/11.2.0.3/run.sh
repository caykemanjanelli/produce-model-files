echo 'Iniciando instalação do Drive Oracle - Jdbc6 - versão 11.2.0.3'
echo ' '
chmod 777 ojdbc6-11.2.0.3.sh
chmod a+x ojdbc6-11.2.0.3.sh
./ojdbc6-11.2.0.3.sh
echo ' '
echo 'Fim da instalação'
