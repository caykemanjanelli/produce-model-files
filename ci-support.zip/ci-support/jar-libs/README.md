# Bibliotecas Básicas Java 

### PROPÓSITO

> Disponibilizar arquivos .jar que não estão disponíveis no repositório oficial do maven

- ATENÇÃO: Você deve ter instalado na sua máquina o **openjdk** (preferencialmente a versão 11) e o **Apache Maven**


#### TECNOLOGIAS ENVOLVIDAS

- Java
- Maven
- Shell script

##### DEPENDÊNCIAS E VERSÕES

- N/A

#### INSTALANDO DEPENDENCIAS:

- ORACLE
  - JDBC 11.2.0.3 [Clique Aqui](com/oracle/jdbc/ojdbc6/11.2.0.3/README.md)
  - JDBC 18.3.0.0 [Clique Aqui](com/oracle/jdbc/ojdbc8/18.3.0.0/README.md)
- TERADATA
  - Teradatajdbc4
    - 15.10.00.37 [Clique Aqui](com/teradata/jdbc/terajdbc4/15.10.00.37/README.md)
    - 16.20.00.10 [Clique Aqui](com/teradata/jdbc/terajdbc4/16.20.00.10/README.md)
  - Tdgssconfig
    - 16.20.00.10 [Clique Aqui](com/teradata/jdbc/tdgssconfig/16.20.00.10/README.md)
    - 16.00.00.01 [Clique Aqui](com/teradata/jdbc/tdgssconfig/16.00.00.01/README.md)

### Baixando o Projeto

**Configurção da Chave SSH**

Open a terminal on Linux or macOS, or Git Bash / WSL on Windows.
```
$ ssh-keygen -t rsa
$ cat ~/.ssh/id_rsa.pub
```
Copie o codigo gerado no terminal (costuma começar com "ssh-ed25..." ou "ssh-rsa ...") e cole no link abaixo:

https://git.cea.com.br/profile/keys

Depois, clique em **Add Key** (não é necessário preencher os demais campos).




**Clone do Projeto via SSH**
```sh
$ git clone git@git.cea.com.br:ci-support/jar-libs.git
$ cd jar-libs/
$ git checkout master
$ echo 'Após rodar o Comando abaixo, Clique enter em todas as opções abaixo, usamos a configuração padrão, como mostra abaixo:'
$ git flow init
$ git checkout develop
```
Retorno experado ao rodar o comando **git flow init**:
```
Which branch should be used for bringing forth production releases?
   - develop
   - master
Branch name for production releases: [master]

Which branch should be used for integration of the "next release"?
   - develop
Branch name for "next release" development: [develop]

How to name your supporting branch prefixes?

Feature branches? [feature/]
Bugfix branches? [bugfix/]
Release branches? [release/]
Hotfix branches? [hotfix/]

Support branches? [support/]

Version tag prefix? []
Hooks and filters directory? [/c/Users/<seu_br>/<path_projeto>/jar-libs/.git/hooks]
```


**Como instalar dependências** 

- Abra o git-bash (Windows) ou o terminal (Linux/Mac) e navegue até o diretório do projeto:
```sh
$ cd /<path_do_projeto_na_sua_maquina>/jar-libs
```

- As libs estão dispostas em pastas de acordo com o package do fornecedor. Por exemplo, para instalar o driver jdbc da oracle versão 8 build 18.3.0.0, navegue conforme abaixo:

```sh
$ cd com/oracle/jdbc/ojdbc8/18.3.0.0
```

- Então, execute o comando de instalação:

```sh
./run.sh
```

- Se você receber o erro **bash: ./run.sh: Permission denied** , transforme o arquivo run.sh em um programa executável:

```sh
$ chmod a+x run.sh
```


### FAQ - CONTATOS - TROUBLESHOOTING 

##### Maintainers: Vikings Squad

##### Desenvolvedores: Vikings Squad
