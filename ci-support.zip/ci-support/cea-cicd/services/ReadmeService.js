const prompt = require('prompt');

const properties = [
    {
        name: 'project-name',
        validator: /^[a-zA-Z0-9\s\-]+$/,
        message: 'Nome do projeto',
        warning: 'O nome do projeto deve conter apenas letras, números e espaços',
        required: true
    },
    {
        name: 'project-description',
        validator: /^[a-zA-Z0-9\s\-]+$/,
        message: 'Descrição',
        warning: 'A descrição do projeto deve conter apenas letras, números e espaços',
        required: true
    },
    {
        name: 'git-group',
        validator: /^[a-z0-9-]+$/,
        message: 'Grupo responsável(o mesmo configurado no gitlab/)',
        warning: 'O nome do time deve conter apenas letras minúsculas, números e traços',
        required: true
    },
    {
        name: 'openshift-namespace',
        validator: /^[a-z0-9-]+$/,
        message: 'Namespace do openshift',
        warning: 'O nome do grupo deve conter apenas letras minúsculas, números e traços',
        required: true
    },
    {
        name: 'artifact-id',
        validator: /^[a-z0-9-]+$/,
        message: 'Artifact Id (este será o nome do objeto resultante do build)',
        warning: 'O artifact id do time deve conter apenas letras minúsculas, números e traços',
        required: true
    },
    {
        name: 'docker-image',
        validator: /^[a-z0-9-]+$/,
        message: 'Imagem docker para o build no ambiente de dev',
        warning: 'O nome da imagem do time deve conter apenas letras minúsculas e números',
        required: true
    }
];


function onError(err){
    console.log(err);
    return 1;
}

function getReadmeProperties(callback){

    prompt.start();

    /**
     * inicia o processo de input do usuario
     */
    prompt.get(properties, function(err, result){
        if(err) {
            return callback(err, null);
        }

        console.log("\n\nEstas serão as informações base do README.md:");
        console.log("Nome do projeto:\t" + result['project-name']);
        console.log("Descrição......:\t" + result['project-description']);
        console.log("Grupo do gitlab:\t" + result['git-group']);
        console.log("Namespace......:\t" + result['openshift-namespace']);
        console.log("Artifact Id....:\t" + result['artifact-id']);
        console.log("Imagem Docker..:\t" + result['docker-image']);

        return callback(err, result);
    });
   
}

module.exports.getReadmeProperties = getReadmeProperties;



