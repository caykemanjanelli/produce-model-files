# Gerador de arquivos CI-CD C&A

### PROPÓSITO

> Projeto Geração de arquivos CI-CD utilizado na esteira Devops


#### TECNOLOGIAS ENVOLVIDAS

- NodeJS

##### DEPENDÊNCIAS E VERSÕES

- NodeJS ([Download](https://nodejs.org/en/download/))

#### Video explicativo ([Clique aqui!](https://web.microsoftstream.com/video/7c731ced-de85-4c1a-b907-861d27602ad4))

### Executando projeto

```sh
$ yarn install
$ yarn start
```